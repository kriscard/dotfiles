local present, fidget = pcall(require, "fidget")
if not present then
  return
end

fidget.setup {}
